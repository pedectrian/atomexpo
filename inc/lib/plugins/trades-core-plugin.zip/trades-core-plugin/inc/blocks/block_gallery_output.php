<?php

	function block_gallery_output ($params) {

		extract($params);

		$block_classes = "outter-wrapper";
		if (!empty($custom_classes)) { $block_classes .= " " . $custom_classes; }
    	
    	// VARS
    	$post_counter = 1;

	    // BUILD EXCLUDE ARRAY
	    $results_exclude_posts = get_posts(array(
	        'numberposts'       => -1,
	        'meta_key'          => 'cmb_hide_from_gallery',
	        'meta_value'        => 'checked',
	        'orderby'           => 'post_date',
	        'order'             => 'DESC',
	        'post_type'         => 'any',
	        'suppress_filters'  => false,
	    ));
	    if (count($results_exclude_posts) > 0) {
	        for ($i = 0; $i < count($results_exclude_posts); $i++) {  
	            $exclude_array[$i] = $results_exclude_posts[$i]->ID;
	        }   
	    } else {
	        $exclude_array = array();   
	    }


	    // BUILD INCLUDE STRING
	    $include_string = "";  

	    if (!empty($cats)) {
	        foreach ($cats as $key => $value) {
	            $include_string .=  get_category_by_slug($key)->term_id . ",";
	        }
	        $include_string = trim($include_string,', ');
	    } 

	   // BASE ARGS
	    $query_args = array(
	        'posts_per_page'    => $num_posts,
	        'post_type'         => 'post',
	        'post_status'       => 'publish',
	        'orderby'           => 'post_date',
	        'order'             => 'DESC',
	        'post__not_in'      => $exclude_array,
	        'cat'               => $include_string,
	         'suppress_filters'  => false,
	  );

		//final query
		$gallery_block_posts = get_posts($query_args);

		?>

		<!-- BLOCK: LATEST POSTS-->

	        <!-- start outter-wrapper -->   
	        <div <?php pb_block_id_class($block_classes, $params); ?> <?php if ($bg_boxed != 'checked') { printf("data-stellar-background-ratio='$parallax_ratio'"); } ?>>

	            <!-- block styles -->
	            <style type="text/css" scoped>
					<?php include 'includes/inc_block_output_style.php'; ?>
	            </style>
	            
	            <!-- start main-container -->
	            <div class="main-container">
	                <!-- start main wrapper -->
	                <div class="main wrapper clearfix" <?php if ($bg_boxed == 'checked') { printf("data-stellar-background-ratio='$parallax_ratio'"); } ?>>
	                    <!-- start main-content -->
	                    <div class="main-content">

							<!-- Start Gallery --> 
							<div class="clearfix">


								<!-- Start Meta -->
								<aside class="clearfix">

									<div class="text-seperator gal-sep">

										<h5><?php echo $params['title']; ?></h5>
										

										<ul class="meta option-set isotope_filter_menu right clearfix">
	                                    <?php

	                                    	if ($hide_filter_menu != "checked") {
		                                        wp_list_categories(array(
		                                            'show_option_all'   => __("All", "loc_trades_core_plugin"),
		                                            'include'           => $include_string,
		                                            'title_li'          => "",
		                                            'taxonomy'          => "category"

		                                        )); 
	                                    	}
	                                    	
	                                    ?>
									  </ul>
									</div>
								
								</aside>

								<!-- Start Isotope -->
								<div class="last thumb-gallery super-list variable-sizes pb_isotope_gallery" data-num_columns="<?php echo $num_columns; ?>">

								<?php

									for ($i = 0; $i < count($gallery_block_posts); $i++) { 


										$current_post = $gallery_block_posts[$i];

			                            $cmb_excerpt = get_post_meta($current_post->ID, 'cmb_excerpt', true);
			                            $cmb_feature = get_post_meta($current_post->ID, 'cmb_feature', true);
			                            $cmb_media_link = get_post_meta($current_post->ID, 'cmb_media_link', true);

			                            // set classes
			                            $base_class = "mosaic-block fade element";
			                            $size_class = " " . mb_get_size_class_from_num($num_columns, 'fourth');
                                        $last_class = ( ($post_counter)%$num_columns ) ? "" : " last";

                                        $categories_class= "";
                                        $item_categories = get_the_terms($current_post->ID, 'category');
                                        if ($item_categories) foreach ($item_categories as $value) $categories_class .= " cat-item-" . $value->term_id;

                                        $final_class = $base_class . $size_class . $categories_class . $last_class;

                                        // FEATURED MEDIA
                                        if ( ($cmb_feature == "media") && (!empty($cmb_media_link)) ) {
                                            echo "<div class='element $size_class $last_class'>";
                                            echo $cmb_media_link;        
                                            echo '</div>';
                                            $post_counter++;
                                        } else {

                                        	//now we know that a featured image has to be displayed so get relevant info
                                            $post_thumbnail_src = wp_get_attachment_image_src(get_post_thumbnail_id($current_post->ID),'full');
                                            $post_thumbnail_src_fit = wp_get_attachment_image_src(get_post_thumbnail_id($current_post->ID),'gallery_isotope_x2');
                                            $img_alt = get_post_meta(get_post_thumbnail_id($current_post->ID), '_wp_attachment_image_alt', true);
                                            $img_post = get_post(get_post_thumbnail_id($current_post->ID));

	                                        if ( ($cmb_feature == "media_in_lightbox") && (!empty($cmb_media_link)) && get_post(get_post_thumbnail_id($current_post->ID)) ) {
	                                            echo "<div class='$final_class'>";
	                                            if ($link_to == "post") {
	                                                printf('<a href="%s" class="mosaic-overlay link fancybox" title="%s"></a>', get_permalink($current_post->ID), esc_attr($img_post->post_title));
	                                            } else {
	                                                printf('<a href="%s" class="mosaic-overlay fancybox fancybox.iframe"></a>', esc_attr($cmb_media_link));
	                                            }
	                                            printf('<div class="mosaic-backdrop"><img src="%s" alt="%s" /></div>', esc_url($post_thumbnail_src_fit[0]), esc_attr($img_alt));
	                                            echo '</div>';
                                                $post_counter++;
	                                        } elseif ( has_post_thumbnail($current_post->ID) && get_post(get_post_thumbnail_id($current_post->ID)) ) { 
	                                            echo "<div class='$final_class'>";
	                                            if ($link_to == "post") {
	                                                printf('<a href="%s" class="mosaic-overlay link fancybox" title="%s"></a>', get_permalink($current_post->ID), esc_attr($img_post->post_title));
	                                            } else {
	                                                printf('<a href="%s" class="mosaic-overlay fancybox" title="%s"></a>', esc_url($post_thumbnail_src[0]), esc_attr($img_post->post_title));
	                                            }
	                                            printf('<div class="mosaic-backdrop"><img src="%s" alt="%s" /></div>', esc_url($post_thumbnail_src_fit[0]), esc_attr($img_alt));
	                                            echo '</div>';
                                                $post_counter++;
	                                        }
                                        		
                                        }
                                        // END FEATURED MEDIA


			                        }

			                     ?>


								</div>
								<!-- end isotope -->

							</div>
							<!-- end gallery -->


	                    </div>
	                    <!-- end main-content -->
	                </div>
	                <!-- end main wrapper -->
	            </div>
	             <!-- end main-container -->
	        </div>
	        <!-- end outter-wrapper -->
	        
		<!-- END BLOCK -->
		
		<?php

		return true;		
	}
