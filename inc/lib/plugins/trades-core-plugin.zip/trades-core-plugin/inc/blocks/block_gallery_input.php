<?php
	function block_gallery_input ($passed_vars) {

		$index = isset($passed_vars[0]) ? $passed_vars[0] : "block_index";
		$params = isset($passed_vars[1]) ? $passed_vars[1] : null;
		$exist = isset($passed_vars[1]) ? true : false;

		// DEFAULTS
		if (!$exist) {
			$params['title'] 						= "My Gallery";
			$params['link_to'] 						= "lightbox";
			$params['num_columns'] 					= 4;
			$params['num_posts'] 					= 8;
			$params['hide_filter_menu'] 			= 'unchecked';

			// APPEARANCE TAB
			$params['tab'] 							= 'block_tab_general';
			$params['use_parallax'] 				= "checked";
			$params['parallax_ratio'] 				= 0.2;
			$params['bg_boxed'] 					= 'unchecked';
			$params['bg_color'] 					= '';
			$params['font_color'] 					= '';

			// ADVANCED TAB
			$params['custom_classes'] 				= '';
			$params['custom_css'] 					= '';
			$params['sticky'] 						= 'unchecked';

		}

		// CAT LIST
		$cat_list = get_categories(array(
			'hide_empty' => 0
		));
		$cat_list = array_values($cat_list);


		?>

			<li class="building_block block_gallery block_group_functionality">

				<div class="block_header">
					<?php _e("Gallery", "loc_trades_core_plugin"); ?>
					<span class="block-edit"></span>
				</div>

				<div class="block_options">

					<input class='block_option' type="hidden" id='block_type' name='canon_options_pagebuilder[blocks][<?php echo $index; ?>][type]' value='gallery'>
					<input class='block_option' type="hidden" id='block_status' name='canon_options_pagebuilder[blocks][<?php echo $index; ?>][status]' value='<?php if (isset($params['status'])) {echo $params['status'];} else {echo "open";} ?>'>
					<input class='block_option' type="hidden" id='block_tab' name='canon_options_pagebuilder[blocks][<?php echo $index; ?>][tab]' value='<?php if (isset($params['tab'])) { echo $params['tab']; } else { echo "block_tab_general"; } ?>'>

				<!--  BLOCK MENU -->
					<?php 
						pb_block_menu(array(
							'block_tab_controls' 		=> array(
								'block_tab_general'			=> __("General", "loc_trades_core_plugin"),
								'block_tab_appearance'		=> __("Appearance", "loc_trades_core_plugin"),
								'block_tab_advanced'		=> __("Advanced", "loc_trades_core_plugin"),
							),
						)); 
					?>


				<!-- BLOCK TAB: GENERAL -->
					<div class="block_tab block_tab_general">


					<!-- TEXT INPUT -->
						<div class="option">
							<label><?php _e("Title", "loc_trades_core_plugin"); ?></label>
							<input class='block_option' type='text' name='canon_options_pagebuilder[blocks][<?php echo $index; ?>][title]' value="<?php if (isset($params['title'])) echo htmlspecialchars($params['title']); ?>">
						</div>
						
					<!-- SELECT -->
						<div class="option">
							<label><?php _e("Images link to", "loc_trades_core_plugin"); ?></label>
							<select class='block_option' id="link_to" name="canon_options_pagebuilder[blocks][<?php echo $index; ?>][link_to]"> 
				     			<option value="post" <?php if (isset($params['link_to'])) {if ($params['link_to'] == "post") echo "selected='selected'";} ?>><?php _e("Posts", "loc_trades_core_plugin"); ?></option> 
				     			<option value="lightbox" <?php if (isset($params['link_to'])) {if ($params['link_to'] == "lightbox") echo "selected='selected'";} ?>><?php _e("Lightbox", "loc_trades_core_plugin"); ?></option> 
							</select> 
						</div>

					<!-- NUMBER -->
						<div class="option">
							<input 
								type='number' 
								class='block_option'
								id='num_columns' 
								name='canon_options_pagebuilder[blocks][<?php echo $index; ?>][num_columns]' 
								min='1'
								max='5'
								step='1'
								style='width: 45px;'
								value='<?php if (isset($params['num_columns'])) echo esc_attr($params['num_columns']); ?>'
							><?php _e("Number of columns", "loc_trades_core_plugin"); ?>
						</div>

					<!-- NUMBER -->
						<div class="option">
							<input 
								type='number' 
								class='block_option'
								id='num_posts' 
								name='canon_options_pagebuilder[blocks][<?php echo $index; ?>][num_posts]' 
								min='1'
								max='1000'
								step='1'
								style='width: 45px;'
								value='<?php if (isset($params['num_posts'])) echo esc_attr($params['num_posts']); ?>'
							><?php _e("Number of posts", "loc_trades_core_plugin"); ?>
						</div>

					<!-- CHECKBOX -->
						<div class="option">
							<input class='block_option' type="hidden" name="canon_options_pagebuilder[blocks][<?php echo $index; ?>][hide_filter_menu]" value="unchecked" />
							<input class='block_option' type="checkbox" name="canon_options_pagebuilder[blocks][<?php echo $index; ?>][hide_filter_menu]" class="checkbox" value="checked" <?php if (isset($params['hide_filter_menu'])) { checked($params['hide_filter_menu'] == "checked"); } ?>/> 
							<?php _e("Hide filter menu", "loc_trades_core_plugin"); ?>
						</div>


					<!-- DYNAMIC CHECKBOXES -->
						<div class="option">
							<label><?php _e("Categories to display in gallery", "loc_trades_core_plugin"); ?></label>
							<?php 
								for ($i = 0; $i < count($cat_list); $i++) { 
								?>
									<input 
										class='block_option checkbox' 
										id='block_cats' 
										type="checkbox" 
										name='canon_options_pagebuilder[blocks][<?php echo $index; ?>][cats][<?php echo $cat_list[$i]->slug; ?>]' 
										value='checked'
										<?php checked(isset($params['cats'][$cat_list[$i]->slug])) ?>
									/> 
									<?php echo $cat_list[$i]->name; ?> <br>
								<?php
								}
							?>
						</div>
						
					</div>
				<!-- END BLOCK TAB: GENERAL -->

					
				<!-- BLOCK TAB: APPEARANCE -->
					<div class="block_tab block_tab_appearance">
						<?php include 'includes/inc_block_appearance_tab.php'; ?>
					</div>


				<!-- BLOCK TAB: ADVANCED -->
					<div class="block_tab block_tab_advanced">
						<?php include 'includes/inc_block_advanced_tab.php'; ?>
					</div>

				</div>
				
			</li>

		<?php	
	}
